Transient Storage 对应代码中需要重新研究 里面有接口

Constructor 构造函数的使用
